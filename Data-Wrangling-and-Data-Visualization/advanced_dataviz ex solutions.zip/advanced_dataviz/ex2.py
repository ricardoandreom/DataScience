#
# Seaborn/Matplotlib
#
import warnings
warnings.filterwarnings("ignore")

import pandas as pd
import seaborn as sns
sns.set()

df = pd.read_csv("../input/iris.csv")

numerical = list(
    set(df.columns)
    - {
        "Species",
        "Id",
    }
)

corr_matrix = df[numerical].corr()
sns.heatmap(corr_matrix);

plot = sns.scatterplot(data=df, x="Sepal Width (cm)", y="Sepal Length (cm)")
plot.set(title='Less correlated variables', xlabel='Sepal Width (cm)', ylabel='Sepal Length (cm)');

plot = sns.scatterplot(data=df, x="Petal Length (cm)", y="Sepal Length (cm)")
plot.set(title='Most correlated variables', xlabel='Petal Length (cm)', ylabel='Sepal Length (cm)');

plot = sns.scatterplot(data=df, x="Petal Length (cm)", y="Sepal Length (cm)", hue="Species")

sns.jointplot(x="Sepal Length (cm)", y="Petal Length (cm)", data=df, kind="scatter", height=4);

#
# Altair
#
import pandas as pd
import altair as alt

# Load dataset
df = pd.read_csv("../input/iris.csv")

# Correlation matrix heatmap
numerical = list(set(df.columns) - {"Species", "Id"})
corr_matrix = df[numerical].corr().reset_index().melt('index')

heatmap = alt.Chart(corr_matrix).mark_rect().encode(
    x='index:O',
    y='variable:O',
    color='value:Q',
    tooltip=['index', 'variable', 'value']
).properties(
    width=300,
    height=300
)

heatmap.display()

# Scatter plot for less correlated variables
scatter1 = alt.Chart(df).mark_circle().encode(
    x='Sepal Width (cm):Q',
    y='Sepal Length (cm):Q'
).properties(
    title='Less correlated variables',
    width=300,
    height=300
)

scatter1.display()

# Scatter plot for most correlated variables
scatter2 = alt.Chart(df).mark_circle().encode(
    x='Petal Length (cm):Q',
    y='Sepal Length (cm):Q'
).properties(
    title='Most correlated variables',
    width=300,
    height=300
)

scatter2.display()

# Scatter plot for most correlated variables with hue by species
scatter3 = alt.Chart(df).mark_circle().encode(
    x='Petal Length (cm):Q',
    y='Sepal Length (cm):Q',
    color='Species:N'
).properties(
    width=300,
    height=300
)

scatter3.display()

# Joint plot for Sepal Length and Petal Length
jointplot = alt.Chart(df).mark_circle().encode(
    x='Sepal Length (cm):Q',
    y='Petal Length (cm):Q'
).properties(
    width=300,
    height=300
)

jointplot.display()
