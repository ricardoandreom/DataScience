# we don't like warnings
# you can comment the following 2 lines if you'd like to
import warnings
warnings.filterwarnings("ignore")

import pandas as pd
import seaborn as sns
sns.set()

import matplotlib.pyplot as plt

df = pd.read_csv("../input/iris.csv")

# Load the required library
from sklearn.decomposition import PCA

# Step 1: drop non-numerical variables
X = df.drop(['Species'], axis=1)

# Step 2: apply PCA and specify the number of components to be generated
pca = PCA(n_components=2)

# Step 3: do a z transformation of the variables
pca_repr = pca.fit_transform(X)

# Step 4: plot the chart with the two components
x = pca_repr[:,0]
y = pca_repr[:,1]

plt.scatter(x, y, cmap = plt.get_cmap('viridis'))

# Option 1: t-SNE using bhtsne
from bhtsne import tsne
from sklearn.preprocessing import StandardScaler

# Your code here
# Step 1: drop non-numerical columns
X = df.drop(['Species'], axis=1)

# Step 2: apply a z transformation to the numerical variables
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Step 3: run t-SNE and plot the results
tsne_repr = tsne(X_scaled)

plt.scatter(tsne_repr[:, 0], tsne_repr[:, 1], alpha=0.5, cmap = plt.get_cmap('viridis'));

# Option 2: t-SNE using sklearn's TSNE package
from sklearn.manifold import TSNE
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt

# Step 1: drop non-numerical columns
X = df.drop(['Species'], axis=1)

# Step 2: apply a z transformation to the numerical variables
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Step 3: run t-SNE and plot the results using sklearn's TSNE
tsne_model = TSNE()
tsne_repr = tsne_model.fit_transform(X_scaled)

plt.scatter(tsne_repr[:, 0], tsne_repr[:, 1], alpha=0.5, cmap=plt.get_cmap('viridis'))
plt.show()
