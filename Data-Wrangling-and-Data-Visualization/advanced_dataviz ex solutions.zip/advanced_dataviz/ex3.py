#
# Seaborn/Matplotlib
#
import warnings
warnings.filterwarnings("ignore")

import pandas as pd
import seaborn as sns

import matplotlib.pyplot as plt

sns.set()

# Read dataset
df = pd.read_csv("../input/iris.csv")

# Your code here
sns.lmplot(x="Sepal Length (cm)", y="Sepal Width (cm)", data=df, hue="Species", fit_reg=False);

# Discard the non-numerical variables for drawing the boxplots
numerical = list(
    set(df.columns)
    - {
        "Species",
        "Id",
    }
)

# The rest of your code here
fig, axes = plt.subplots(nrows=1, ncols=4, figsize=(20, 5))

for idx, feat in enumerate(numerical):
    ax = axes[idx % 4]
    sns.boxplot(x="Species", y=feat, data=df, ax=ax)
    ax.set_xlabel("")
    ax.set_ylabel(feat)

fig.tight_layout();

_, axes = plt.subplots(1, 2, sharey=True, figsize=(10, 4))

sns.boxplot(x="Species", y="Sepal Length (cm)", data=df, ax=axes[0])
sns.violinplot(x="Species", y="Sepal Length (cm)", data=df, ax=axes[1]);

# Step 1: Create a categorical variable out of Sepal Length where there are 5 classes, one for 4.5, 4.6, ..., 5 (tip: use the Pandas function between())
df_aux = df[df["Sepal Length (cm)"].between(4.5, 5)]

# Step 2: draw the plot
sns.countplot(x=df_aux["Sepal Length (cm)"], hue="Species", data=df);

#
# Altair
#
import pandas as pd
import altair as alt

# Read dataset
df = pd.read_csv("../input/iris.csv")

# Scatter plot with regression line
scatter = alt.Chart(df).mark_circle().encode(
    x='Sepal Length (cm):Q',
    y='Sepal Width (cm):Q',
    color='Species:N'
)

scatter.display()

# Boxplots for each numerical feature
numerical = list(set(df.columns) - {"Species", "Id"})
boxplots = [alt.Chart(df).mark_boxplot().encode(
    y=f'{feat}:Q',
    x='Species:O'
).properties(title=feat, width=150, height=150) for feat in numerical]

alt.hconcat(*boxplots).display()

# Boxplot and violin plot side-by-side for Sepal Length
boxplot = alt.Chart(df).mark_boxplot().encode(
    y='Sepal Length (cm):Q',
    x='Species:O'
).properties(width=300, height=300)

violinplot = alt.Chart(df).mark_area().encode(
    x='Species:O',
    y=alt.Y('Sepal Length (cm):Q', title=''),
    color='Species:N',
    row='Species:N'
).transform_density(
    density='Sepal Length (cm)',
    as_=['Sepal Length (cm)', 'density'],
    groupby=['Species']
)

(alt.hconcat(boxplot, violinplot)).display()

# Count plot for Sepal Length between 4.5 and 5 with hue by species
df_aux = df[df["Sepal Length (cm)"].between(4.5, 5)]
countplot = alt.Chart(df_aux).mark_bar().encode(
    x='Sepal Length (cm):O',
    y='count()',
    color='Species:N'
)

countplot.display()
