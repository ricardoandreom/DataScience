#
# Seaborn / Matplotlib
#
import warnings
warnings.filterwarnings("ignore")

import pandas as pd

# We will use the Seaborn library
import seaborn as sns
sns.set()

df = pd.read_csv("../input/iris.csv")

df.head()

features = ["Sepal Length (cm)", "Petal Length (cm)"]
df[features].hist(figsize=(10, 4));

df[features].plot(
    kind="density", subplots=True, layout=(1, 2), sharex=False, figsize=(10, 4)
);

sns.distplot(df["Sepal Width (cm)"])

#
# Altair
#
import pandas as pd
import altair as alt

# Load dataset
df = pd.read_csv("../input/iris.csv")
df.head()

# Histogram for Sepal Length and Petal Length
hist1 = alt.Chart(df).mark_bar().encode(
    alt.X("Sepal Length (cm):Q", bin=True),
    y='count()'
).properties(width=300, height=200, title="Sepal Length (cm)")

hist2 = alt.Chart(df).mark_bar().encode(
    alt.X("Petal Length (cm):Q", bin=True),
    y='count()'
).properties(width=300, height=200, title="Petal Length (cm)")

(hist1 | hist2).display()

# Density plot for Sepal Length and Petal Length
density1 = alt.Chart(df).mark_area(opacity=0.3).encode(
    alt.X("Sepal Length (cm):Q", bin=alt.Bin(maxbins=100)),
    alt.Y('count()', stack=None)
).properties(width=300, height=200, title="Sepal Length (cm) Density")

density2 = alt.Chart(df).mark_area(opacity=0.3).encode(
    alt.X("Petal Length (cm):Q", bin=alt.Bin(maxbins=100)),
    alt.Y('count()', stack=None)
).properties(width=300, height=200, title="Petal Length (cm) Density")

(density1 | density2).display()

# Density plot for Sepal Width
density_sepal_width = alt.Chart(df).mark_area(opacity=0.3).encode(
    alt.X("Sepal Width (cm):Q", bin=alt.Bin(maxbins=100)),
    alt.Y('count()', stack=None)
).properties(width=300, height=200, title="Sepal Width (cm) Density")

density_sepal_width.display()